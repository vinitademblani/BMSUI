export class City
{
    cityId:number;
    cityName:String;
}
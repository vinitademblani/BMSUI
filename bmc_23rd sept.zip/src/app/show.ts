export class Show
{
    showId:number;
    noOfSeats:number;
    showTime:string;
    movieName:string;
    imageName:string
    image:any;
}
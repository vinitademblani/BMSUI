import { Component, OnInit, forwardRef,EventEmitter,Output } from '@angular/core';
import { Observable } from 'rxjs';
import {City} from '../City';
import {Show } from '../Show';
import { CityService } from '../city.service';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css'],
   
})
export class NavigationComponent implements OnInit {
cityObserver:Observable<City[]>;
showObserver:Observable<Show[]>;
cityArray:City[];
showArray:Show[];
selected='';
@Output()
public emitShowData=new EventEmitter<any>();

  constructor(private cityService:CityService) { }

  ngOnInit() {
    this.cityObserver=this.cityService.getCities();
    this.cityObserver.subscribe(
      (response)=>{
        this.cityArray=response,
        console.log(response)},
      (error:any)=>{console.log(error)},
      ()=>{console.log('completed')}
    );
  }
  onChange(city)
  {
    this.selected=city.cityId;
    
    console.log('city name selected is ',city.cityName);
    this.showObserver=this.cityService.getAllShowsByCityName(this.selected);
    this.showObserver.subscribe(
      (response)=>{this.showArray=response,
      console.log(response)},
    (error:any)=>{console.log(error)},
    ()=>{console.log('completed')}
    );
  }

  sendShowArray(showArray):void{
    console.log('data send from navigation',this.showArray);
    this.emitShowData.emit(this.showArray);
  }

 
}
